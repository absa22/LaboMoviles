package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Trace;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity implements View.OnLongClickListener {

    AutoCompleteTextView fruta, animal, lenguaje;
    Button btprocesar;
    String[] frut = { "mango","Limon","jocote" };
    String[] lengua = { "C#","JAVA","C" };
    String[] anima = { "Leon","aguila","caballo" };
    ProgressBar barra;
    boolean activo = false;
    int i = 0;
    Handler h = new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btprocesar= findViewById(R.id.btnprocesar);
        btprocesar.setOnLongClickListener(this);

        if(getSupportActionBar()!=null)
        {
            getSupportActionBar().setTitle("Guia 2");
        }

        fruta = findViewById(R.id.txtfruta);
        animal = findViewById(R.id.txtanimal);
        lenguaje = findViewById(R.id.txtlenguaje);
        btprocesar = findViewById(R.id.btnprocesar);
        barra = findViewById(R.id.bar);

        ArrayAdapter<String> adapteranimal = new ArrayAdapter<>(this,android.R.layout.select_dialog_item,anima);
        ArrayAdapter<String> adapterfruta = new ArrayAdapter<>(this,android.R.layout.select_dialog_item,frut);
        ArrayAdapter<String> adapterlenguaje = new ArrayAdapter<>(this,android.R.layout.select_dialog_item,lengua);

        animal.setThreshold(1);
        animal.setAdapter(adapteranimal);

        fruta.setThreshold(1);
        fruta.setAdapter(adapterfruta);

        lenguaje.setThreshold(1);
        lenguaje.setAdapter(adapterlenguaje);

        btprocesar.setOnLongClickListener(this);
    }



    public void mensaje(View view) {
        Toast notificacion = Toast.makeText(this, "el usuario selecciono: ", Toast.LENGTH_LONG);
        notificacion.show();
    }


    @Override
    public boolean onLongClick(View view) {

        switch (view.getId()){
            case R.id.btnprocesar: {

                Thread carga = new Thread(new Runnable() {
                    @Override
                    public void run() {


                        while (i <= 100) {
                            h.post(new Runnable() {
                                @Override
                                public void run() {
                                    barra.setProgress(i);
                                }
                            });
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            if(i==100)
                            {

                            }
                            i = i+20;
                        }
                    }
                });  carga.start();
            }break;
        }
        return false;
    }
}

