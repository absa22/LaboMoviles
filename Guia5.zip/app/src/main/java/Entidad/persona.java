package Entidad;

public class persona {
    private String nombre;
    private String conversacion;

    public persona(String nombre, String conversacion) {
        this.nombre = nombre;
        this.conversacion = conversacion;
    }

    public persona() {

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getConversacion() {
        return conversacion;
    }

    public void setConversacion(String conversacion) {
        this.conversacion = conversacion;
    }
}
