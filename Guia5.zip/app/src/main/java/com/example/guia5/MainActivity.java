package com.example.guia5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {

            case R.id.btnlogin:
            {
                Intent hi = new Intent(this, login.class);
                startActivity(hi);
                break;
            }


            case R.id.btncalculadora:
            {
                Intent hi = new Intent(this, calculadora.class);
                startActivity(hi);
                break;
            }

            case R.id.btnconversation:
            {
                Intent hi = new Intent(this, conversation.class);
                startActivity(hi);
                break;
            }

        }
    }
}
