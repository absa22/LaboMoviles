package com.example.guia5;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import Adaptador.adaptad;
import Entidad.persona;

public class conversation extends AppCompatActivity {
    ListView lista;
    List<persona> listax = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_conversation);
        lista = findViewById(R.id.listaconversacion);

        //instancia de clase persona
        persona p = new persona();

        listax.add( new persona("Samuel Absalon Herrera", "Codigo: HC15I04002 correlativo:#5") );
        listax.add( new persona("Eli", "El amor de life") );
        listax.add( new persona("Neto", "Mi amigo instructor vergon :v") );

        lista.setAdapter(new adaptad(this, R.layout.plantilla,listax));


    }
}
