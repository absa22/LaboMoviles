package Adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.example.guia4.R;
import Entidades.Registro;

import java.util.List;

public class AdaptadorRegistro extends BaseAdapter {
    private List<Registro> datasource;
    private Context cntx;
    private int IdLayoutPlantilla;

    public List<Registro> GetData() {
        return this.datasource;
    }

    /**
     * Constructor que permite inicializar las variables de la clase
     *
     * @param context
     * @param IdPlantilla
     * @param sources
     */

    public AdaptadorRegistro(Context context, int IdPlantilla, List<Registro> sources) {
        //Inicializamos las variables
        this.cntx = context;
        this.IdLayoutPlantilla = IdPlantilla;
        this.datasource = sources;
    }

    @Override
    public int getCount() {
        return this.datasource.size();
    }

    @Override
    public Registro getItem(int position) {
        return this.datasource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {

            LayoutInflater inflater = (LayoutInflater) this.cntx.getSystemService(this.cntx.LAYOUT_INFLATER_SERVICE);

            convertView = inflater.inflate(this.IdLayoutPlantilla, null);


            TextView txvNombre = convertView.findViewById(R.id.txvNombre);
            TextView txvTelefono = convertView.findViewById(R.id.txvTelefono);
            TextView txvOrganizacion = convertView.findViewById(R.id.txvOrganizacion);

            txvNombre.setText(this.datasource.get(position).getNombre());
            txvTelefono.setText(this.datasource.get(position).getTelefono());
            txvOrganizacion.setText(this.datasource.get(position).getOrganizacion());

        }
        return convertView;
    }
}