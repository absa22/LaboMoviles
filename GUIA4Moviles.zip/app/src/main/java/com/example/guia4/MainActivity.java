package com.example.guia4;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import Adaptadores.AdaptadorRegistro;
import Entidades.Registro;
import butterknife.BindView;
import butterknife.ButterKnife;



public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ListView listRegistros;
    public static List<Registro> listaRegistros;
    public static Registro itemRegistro;
    //FloatingActionButton fabAdd;
    @BindView(R.id.fabAdd) FloatingActionButton fabAdd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setToolbar();
        listRegistros = findViewById(R.id.list_item);
        this.listaRegistros = new ArrayList<>();
        itemRegistro = new Registro();
        ButterKnife.bind(this);
        fabAdd.setOnClickListener(this);

        listRegistros.setAdapter(new AdaptadorRegistro(this, R.layout.plantilla_registro, listaRegistros));
        listRegistros.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Registro RegisSel = listaRegistros.get(position);
                if (RegisSel != null) {
                    Toast.makeText(MainActivity.this, "Usted selecciono : " + RegisSel.getNombre(), Toast.LENGTH_LONG).show();
                }

            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.fabAdd: {
                Intent i = new Intent(MainActivity.this, FormRegistro.class);
                startActivity(i);
            }
            break;
        }
    }

    public void setToolbar() {
        Toolbar toolbar = findViewById(R.id.activity_my_toolbar);
        toolbar.setTitle("Lista Principal");
        setSupportActionBar(toolbar);
    }
}

