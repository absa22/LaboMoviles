package com.example.guia4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import Entidades.Registro;
import butterknife.BindView;
import butterknife.ButterKnife;
import eu.inmite.android.lib.validations.form.FormValidator;
import eu.inmite.android.lib.validations.form.annotations.MinLength;
import eu.inmite.android.lib.validations.form.annotations.NotEmpty;
import eu.inmite.android.lib.validations.form.callback.SimpleErrorPopupCallback;

import static com.example.guia4.MainActivity.itemRegistro;
import static com.example.guia4.MainActivity.listaRegistros;

public class FormRegistro extends AppCompatActivity implements View.OnClickListener {

    @BindView(R.id.edtNombre)
    @NotEmpty(messageId = R.string.ValidarNombre, order = 1)
    EditText edtNombre;

    @BindView(R.id.edtTel)
    @NotEmpty(messageId = R.string.ValidarTelefono, order = 2)
    @MinLength(value = 8, messageId = R.string.Tamanio, order = 3)
    EditText edtTel;

    @BindView(R.id.edtOrg)
    @NotEmpty(messageId = R.string.ValidarOrganizacion, order = 4)
    EditText edtOrg;

    @BindView(R.id.btnGuardar)
    Button btnGuardar;

    @BindView(R.id.btnDatos)
    Button btnDatos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        ButterKnife.bind(this);
        setToolbar();
        btnGuardar.setOnClickListener(this);
        btnDatos.setOnClickListener(this);
    }

    public void setToolbar() {
        Toolbar toolbar = findViewById(R.id.activity_my_toolbar);
        toolbar.setTitle("FormRegistro");
        setSupportActionBar(toolbar);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnGuardar: {
                if (FormValidator.validate(this, new SimpleErrorPopupCallback(this))) {
                    itemRegistro.setNombre(edtNombre.getText().toString());
                    itemRegistro.setTelefono(edtTel.getText().toString());
                    itemRegistro.setOrganizacion(edtOrg.getText().toString());
                    if (!itemRegistro.getNombre().isEmpty() && !itemRegistro.getTelefono().isEmpty() && !itemRegistro.getOrganizacion().isEmpty()) {
                        listaRegistros.add(itemRegistro);
                        itemRegistro = new Registro();
                        finish();
                        Toast.makeText(this, edtNombre.getText().toString() + " Agregado a la Lista", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
            case R.id.btnDatos: {
                Intent datos = new Intent(this, Datos.class);
                startActivity(datos);
            }
            break;
        }
    }
}
