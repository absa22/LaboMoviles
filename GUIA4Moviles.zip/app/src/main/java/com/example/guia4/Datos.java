package com.example.guia4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

public class Datos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos);
        setToolbar();
    }
    public void setToolbar() {
        Toolbar toolbar = findViewById(R.id.activity_my_toolbar);
        toolbar.setTitle("Mis datos");
        setSupportActionBar(toolbar);
    }
}
